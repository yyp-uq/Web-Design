const wrapper = document.querySelector('.scroll-snapper');
let isScrolling = false;
let lastScrollDirection = 0;

wrapper.addEventListener('wheel', (event) => {
  event.preventDefault();
  const scrollAmount = window.innerHeight;
  const direction = event.deltaY > 0 ? 1 : -1;

  if (!isScrolling) {
    if (direction > 0) {
      wrapper.scrollTop += scrollAmount;
    } else {
      wrapper.scrollTop -= scrollAmount;
    }
    isScrolling = true;
    lastScrollDirection = direction;
    setTimeout(() => {
      isScrolling = false;
      lastScrollDirection = 0;
    }, 1000);
  } else {
    return;
  }
}, { passive: false });

function toggleMenu(side) {
  const leftMenu = document.getElementById('left-options');
  const rightMenu = document.getElementById('right-options');
  const leftBtn = document.getElementById('left-menu-btn');
  const rightBtn = document.getElementById('right-menu-btn');

  if (side === 'left') {
    leftMenu.classList.toggle('show');
    leftBtn.classList.toggle('rotated');
  } else {
    rightMenu.classList.toggle('show');
    rightBtn.classList.toggle('rotated');
  }
}

const sectionsWrapper = document.querySelector('.scroll-snapper');
const header = document.querySelector('.main-header');

sectionsWrapper.addEventListener('scroll', () => {
  if (sectionsWrapper.scrollTop > window.innerHeight * 0.5) {
    header.classList.add('hidden');
  } else {
    header.classList.remove('hidden');
  }
});

function openVideo() {
  const modal = document.getElementById('videoModal');
  const player = document.getElementById('youtubePlayer');
  modal.style.display = 'flex';
  player.src = "https://www.youtube.com/embed/ZdVO_fYoF5g?autoplay=1";
}

function closeVideo() {
  const modal = document.getElementById('videoModal');
  const player = document.getElementById('youtubePlayer');
  modal.style.display = 'none';
  player.src = "";
}

document.getElementById('playVideoBtn').addEventListener('click', openVideo);
