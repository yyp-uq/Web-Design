// Smooth scroll snapping like character.js
const scrollContainer = document.querySelector('.scroll-snapper');
const header = document.querySelector('.main-header');

// Control the header show/hide based on scroll position
scrollContainer.addEventListener('scroll', () => {
  const scrollTop = scrollContainer.scrollTop;
  const windowHeight = window.innerHeight;

  if (scrollTop >= windowHeight * 0.5) {
    header.classList.add('hidden');
  } else {
    header.classList.remove('hidden');
  }
});

// Control smooth wheel scrolling by snapping one full screen at a time
let isScrolling = false;

scrollContainer.addEventListener('wheel', (event) => {
  event.preventDefault();
  const scrollAmount = window.innerHeight;
  const direction = event.deltaY > 0 ? 1 : -1;

  if (!isScrolling) {
    if (direction > 0) {
      scrollContainer.scrollTop += scrollAmount;
    } else {
      scrollContainer.scrollTop -= scrollAmount;
    }
    isScrolling = true;
    setTimeout(() => {
      isScrolling = false;
    }, 1000);
  }
}, { passive: false });

// 选择所有武器图片
const weaponBlocks = document.querySelectorAll('.weapon-block');
const weaponDetail = document.getElementById('weapon-detail');
const weaponTitle = document.getElementById('weapon-title');
const weaponInfo = document.getElementById('weapon-info');

// 预设超详细的武器介绍和颜色
const weaponDetails = {
  "Naydra's Horn Weapon": {
    info: `
Naydra's Horn Weapon is created by fusing a weapon with the horn of Naydra, the sacred Ice Dragon that soars above the frozen Lanayru Mountain Range. Naydra represents purification and rebirth, having once been corrupted by malice until Link restored its true form.

The horn contains pure ice energy. When fused with a weapon, it grants powerful frost attacks that freeze enemies instantly, offering excellent crowd control and making it especially effective against fiery foes.

Wielding this weapon is not just a show of strength, but a symbol of the hero’s will to protect Hyrule. According to legend, Naydra’s icy breath sealed away corruption, preserving the land’s purity.

Obtaining Naydra’s horn requires tracking the dragon through freezing skies and striking its horn mid-flight—a challenge demanding precision and resilience. As a result, the weapon is rare and highly valued, both for its elemental power and its deep connection to the spiritual lore of Hyrule.
    `,
    color: "white"
  },
  "Farosh's Horn Weapon": {
    info: `
Farosh's Horn Weapon is forged by combining a weapon with the horn of Farosh, the mighty Thunder Dragon who roams the skies above the Faron region and Gerudo Highlands. Farosh represents raw energy, unpredictability, and the natural force of electricity. When fused into a weapon, its horn channels high-voltage power capable of stunning and paralyzing enemies on impact.

This electrified weapon is especially effective in disabling groups of foes or mechanical enemies, giving the wielder control over chaotic encounters. The crackling energy is not just powerful—it embodies the wild and untamed spirit of Farosh itself.

According to legend, Farosh was once a guardian of ancient shrines, feared and revered by all who witnessed its lightning trails across the heavens. Obtaining the horn requires navigating thunderstorms and gliding close to strike the airborne dragon—a feat of both timing and courage.

Because of its electrifying effects and sacred origin, Farosh’s Horn Weapon is considered a treasured tool for warriors who seek not only strength, but dominion over the forces of nature.


    `,
    color: "white"
  },
  "Dinraal's Horn Weapon": {
    info: `
Dinraal's Horn Weapon is crafted by fusing a weapon with the blazing horn of Dinraal, the Fire Dragon who glides through the canyons of Eldin and the northern sky. Representing destruction, transformation, and passion, Dinraal wields the ancient flame of Hyrule. Weapons infused with its horn unleash searing fire attacks that ignite enemies and burn obstacles instantly.

This fire-enhanced weapon excels in clearing out swarms, melting ice barriers, or applying constant damage to tough opponents. Its sheer heat makes it one of the most aggressive elemental weapons available.

Legend holds that Dinraal’s flames once sealed away ancient evils deep beneath Death Mountain. To earn this horn, players must brave intense heat, high winds, and precisely strike Dinraal while it soars in open skies—requiring skill, patience, and protective gear.

The weapon symbolizes relentless strength and the power of rebirth through fire. Dinraal’s Horn Weapon is a true emblem of destruction wielded for righteous purpose, favored by warriors unafraid to scorch a path through chaos.


    `,
    color: "white"
  },
  "Light Dragon's Horn Weapon": {
    info: `
Light Dragon's Horn Weapon is a sacred fusion of a weapon and the horn of the Light Dragon, the divine serpent who glides across the skies of all Hyrule. Unlike other dragons, the Light Dragon embodies restoration, purity, and the spirit of courage itself—bearing deep ties to Zelda’s transformation in the events of Tears of the Kingdom.

The horn grants a radiant energy effect. While it lacks elemental damage, it boosts weapon durability, restores lost strength, and emits a holy aura that glows with celestial light. It’s a support-oriented weapon, ideal for long battles where endurance and blessings outweigh raw offense.

Legends say the Light Dragon was born from sacrifice and duty, chosen to guide and protect the land silently from above. Acquiring its horn requires patience, timing, and reverence—striking it mid-flight as it travels gracefully through the sky.

Light Dragon’s Horn Weapon is rare and revered. Though not the most powerful in direct combat, it holds unmatched symbolic value and is a beacon of divine grace for any true hero of Hyrule.


    `,
    color: "white"
  }
};

weaponBlocks.forEach(block => {
  block.addEventListener('click', () => {
    const title = block.querySelector('h3').innerText;
    const detail = weaponDetails[title];

    if (detail) {
      weaponTitle.innerText = title;
      weaponInfo.innerText = detail.info;
      weaponTitle.style.color = detail.color;
      weaponInfo.style.color = detail.color;
    } else {
      weaponTitle.innerText = "Unknown Weapon";
      weaponInfo.innerText = "No details available.";
      weaponTitle.style.color = "#ffffff";
      weaponInfo.style.color = "#ffffff";
    }

    // 先彻底移除 show
    weaponDetail.classList.remove('show');
    weaponDetail.classList.remove('hidden');

    // ✅ 关键：强制回流一次，刷新DOM
    void weaponDetail.offsetWidth;

    // 再添加 show，重新触发动画
    weaponDetail.classList.add('show');
  });
});
